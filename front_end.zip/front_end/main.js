var app = (function() {
    var pessoas = {};
    var treinamentos = {};
    var idPessoa = 0;
    var idTreinamento = 0;

    // Função para limpar a caixa de texto
    function limparCaixaDeTexto(id) {
        document.getElementById(id).value = '';
    }

    return {
        cadastrarPessoa: function(nome) {
            var id = ++idPessoa;
            pessoas[id] = {nome: nome, treinamentos: {}};
            limparCaixaDeTexto('nomePessoa');  // Limpa a caixa de texto após a inserção do dado
            return {id: id, nome: nome};
        },
        cadastrarTreinamento: function(nome) {
            var id = ++idTreinamento;
            treinamentos[id] = nome;
            limparCaixaDeTexto('nomeTreinamento');  // Limpa a caixa de texto após a inserção do dado
            return {id: id, nome: nome};
        },
        buscarPessoa: function(id) {
            limparCaixaDeTexto('buscaPessoa');  // Limpa a caixa de texto após a pesquisa
            return pessoas[id];
        },
        buscarTreinamento: function(id) {
            limparCaixaDeTexto('buscaTreinamento');  // Limpa a caixa de texto após a pesquisa
            return treinamentos[id];
        },
        deletarPessoa: function(id) {
            limparCaixaDeTexto('idPessoa');  // Limpa a caixa de texto após a deleção
            delete pessoas[id];
        },
        deletarTreinamento: function(id) {
            limparCaixaDeTexto('idTreinamento');  // Limpa a caixa de texto após a deleção
            delete treinamentos[id];
        },
        atribuirTreinamento: function(idPessoa, idTreinamento, status) {
            if(pessoas[idPessoa] && treinamentos[idTreinamento]) {
                pessoas[idPessoa].treinamentos[idTreinamento] = status;
                limparCaixaDeTexto('idPessoa');  // Limpa a caixa de texto após a atribuição
                limparCaixaDeTexto('nomeTreinamentoIndividuo');  // Limpa a caixa de texto após a atribuição
                return {pessoa: pessoas[idPessoa], treinamento: treinamentos[idTreinamento]};
            }
            return false;
        }
    };
})();

